const express = require('express');
const router = express.Router();
const { register, login } = require('../controller/AuthController');

router.post('/register', register);  // API 1
router.post('/login', login);        // API 2

module.exports = router;
