const User = require('../model/userModel');
const jwt = require('jsonwebtoken');

exports.register = async (req,res)=>{
  try {
    const { name, email, password } = req.body;
    const user = await User.create({ name, email, password });
    res.json({ msg: 'User registered', user });
  } catch (err) { res.status(500).json(err); }
}

exports.login = async (req,res)=>{
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if(!user) return res.status(400).json({ msg: 'Invalid credentials' });

    const isMatch = await user.comparePassword(password);
    if(!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.json({ msg: 'Login successful', token });
  } catch (err) { res.status(500).json(err); }
}
