

function welcome(req,res){
    res.send("Welcome to the central library \n1) Add user /addUser \n2) Add Book /addBook \n3) Book Transaction /bookTransaction")
}
function addUser(req,res){
    const b = req.body || {};
  const doc = {
    name: b.name,
    accountNumberLast4: String(b.accountNumberLast4 || ''),
    cardNumber: String(b.cardNumberLast4 || ''),
    mobileNumber: String(b.mobileNumber || ''),
    email: b.email || '',
    pin: String(b.pin || ''),
    balance: INITIAL_BALANCE,
    blocked: false,
    transactions: []
  };

  if (!doc.name || !doc.accountNumberLast4 || !doc.cardNumber || !doc.mobileNumber || !doc.pin) {
    return res.status(400).send("All fields are required: name, accountNumberLast4, cardNumberLast4, mobileNumber, pin");
  }

  findAccount(doc.cardNumber)
    .then(existing => {
      if (existing) return res.status(400).send("Card already exists");
      return createAccount(doc)
        .then(() => res.send("Card created successfully, please login with /insert"));
    })
    .catch(err => res.status(500).send(err.message || String(err)));
}



module.exports = {
    welcome
}